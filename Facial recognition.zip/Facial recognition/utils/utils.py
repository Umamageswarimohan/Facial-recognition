
# Text to speech
import pyttsx3

import os
import pickle

class Utils:
    
    def createDirectory(self, dir_path : str) ->None:
        if not os.path.exists(dir_path):
            print(f"{dir_path} Directory created... !")
            os.makedirs(dir_path)
            
    def savePickleModel(self, model_dir : str, filename : str, data : list):
        pickle.dump(data, open(f"{model_dir}/{filename}", 'wb'))
        print(f"Pickled {model_dir}/{filename} Successfully...")
        
    def loadPickleModel(self, model_path : str) -> pickle.load :
        return pickle.load(open(model_path, 'rb'))
    
    def speakText(self, text : str) -> None:
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()