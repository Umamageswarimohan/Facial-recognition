

import numpy as np

import cv2

from keras.models import load_model
from keras_preprocessing.image import img_to_array

class GenderDetection:
    
    def __init__(self) -> None:
        self.__classes = ['man','woman']
        
        # Load model
        self.__model = load_model('gender_detection_model/gender_detection.model')

        
    def __cropFrame(self, frame : np.ndarray, locations:list) -> np.ndarray:
        
        [l, t, r, b]  = locations
        face_crop = frame[t:b, l:r]
        face_crop = cv2.resize(face_crop, (96,96))
        face_crop = face_crop.astype("float") / 255.0
        face_crop = img_to_array(face_crop)
        face_crop = np.expand_dims(face_crop, axis=0)
        return face_crop
    
    def predict(self, frame : np.ndarray, locations:list) -> str:
        
        __cFrame = self.__cropFrame(frame=frame, locations=locations)
        
        __conf = self.__model.predict(__cFrame)[0]
        return self.__classes[np.argmax(__conf)]
        
        
        