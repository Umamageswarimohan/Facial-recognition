
# OpenCV
import cv2


class Camera:
    
    def __init__(self, cam_index : int = 0, cam_prop : cv2 = cv2.CAP_DSHOW):
        
        self.run = True
        self.cap = cv2.VideoCapture(cam_index, cam_prop)
        
    def setCamWidth(self, width : int = 640) -> None:
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        
    def setCamHeight(self, height : int = 480) -> None:
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        
    def _setCamSize(self) -> None:
        self.setCamHeight()
        self.setCamWidth()
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 2)

        
    def start(self) -> None:
        
        self._setCamSize()
        
        while self.run :
            
            _, __frame = self.cap.read()
            
            cv2.imshow("Frame", __frame)
            
            if self._stopCam():
                break
            
    def _stopCam(self, forceStop: bool = False) -> None:
        if cv2.waitKey(1) & 0xff == ord('q'):
            return True
        if forceStop:
            return False
        return False
    
    def stopCam(self, forceStop : bool = False):
        self.__stopCam(forceStop=forceStop)
    
    def __del__(self):
        self.cap.release()
        cv2.destroyAllWindows()
        
        