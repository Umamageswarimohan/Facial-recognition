
# Face Recognition Pacakge
from typing import Any
import face_recognition

import numpy as np

from PIL import Image

class FaceRecognition:
    
    def __init__(self) -> None:
        pass
    
    def convertToPilFormat(self, image : np.ndarray) -> Image:
        return Image.fromarray(image)
    
    def __load_image_from_file(self, file_path : str) -> np.ndarray :
        
        # load image into face recognition format
        return face_recognition.load_image_file(file_path)
    
    def __get_face_locations(self, fr_img : np.array) -> list[tuple[int, Any, Any, int]]:
        
        # get face locations
        return face_recognition.face_locations(fr_img)
    
    def __get_face_encodings(self, fr_img : np.array = np.ndarray, findFace : bool = False, faceLocations : list[tuple[int, Any, Any, int]] = None ) -> list[np.ndarray]:
                # load image to face recognition method
        #face_recognition_image = self.__load_image_from_file(file_path=f"{img_dir}/{filename}")#face_recognition.load_image_file(f"{img_dir}/{filename}")
        
        # Get face encodings
        face_recognition_image_encodings = face_recognition.face_encodings(fr_img) if not findFace else face_recognition.face_encodings(fr_img, faceLocations)
        
        return face_recognition_image_encodings
    
    def compareFaces(self, known_face_encodings : list, faceEncoding :  list[np.ndarray]) -> list:
        return face_recognition.compare_faces(known_face_encodings, faceEncoding)
    
    #def __get_face_locations(self, )