import cv2


# Threading 
import threading

# OpenCV
import cv2
import cvlib as cv
import time

# PIL package
from PIL import ImageDraw

# Face Recognition package
# import face_recognition
import numpy as np

from utils.utils import Utils
from utils._faceRecognition import FaceRecognition
from utils._camera import Camera
#from utils._genderDetection import GenderDetection


utils = Utils()
print("Model loaded successfully...\n")
    
known_name_model = utils.loadPickleModel("model/known-names.pkl")
known_face_encoding_model = utils.loadPickleModel("model/known-face-encodings.pkl")

def detect_face(image):
    pervName = None
    # Convert the image to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    rgb_frame = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    # Apply a face detection cascade
    face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    face_locations = FaceRecognition()._FaceRecognition__get_face_locations(rgb_frame)
            
            # Get face encodings
    face_encodings = FaceRecognition()._FaceRecognition__get_face_encodings(fr_img=rgb_frame, findFace=True, faceLocations=face_locations)
      
    # Draw a rectangle around each face
    for face_encoding, (x, y, w, h) in zip(face_encodings, faces):
        cv2.rectangle(image, (x, y), (x + w, y + h), (255, 0, 0), 2)
        
        matches = FaceRecognition().compareFaces(known_face_encoding_model, face_encoding)
        print(matches)
        name = "Unknonw Person"
        if True in matches:
            name = known_name_model[matches.index(True)]
        #s = self.__genderDetection.predict(image, [l, t, r, b])
        print(name)
        
        if name != pervName:
            utils.speakText(f"{name}")
            pervName = name
        
        cv2.rectangle(image, (h,w - len(name) - 10), (y, w), color=(0, 0, 0), thickness=-1 )
        cv2.putText(image, name, (h+6, -len(name) + 5), fontScale=0.5, color=(255, 255, 255),fontFace=cv2.FONT_HERSHEY_PLAIN ,thickness=1) 


    return image

if __name__ == "__main__":
    # Open the webcam
    cap = cv2.VideoCapture(2)

    while True:
        # Read the current frame from the webcam
        ret, frame = cap.read()

        # Perform face detection on the frame
        face_image = detect_face(frame)

        # Display the frame with the detected faces
        
        cv2.imshow('Face Detection', face_image)

        # Exit the loop if 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release the webcam and close the windows
    cap.release()
    cv2.destroyAllWindows()
