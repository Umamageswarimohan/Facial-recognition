
from utils._faceRecognition import FaceRecognition
from utils.utils import Utils

import os

class TrainFaces(Utils):
    
    def __init__(self, 
                 known_names_filename : str = "known-names.pkl", 
                 known_encoding_filename : str ="known-face-encodings.pkl",
                 image_dir : str = 'images',
                 model_dir : str = "model") -> None:
        
        # train image directory
        self.images_dir = image_dir
        
        # model directory
        self.__model_dir = model_dir
        # check if the directory is created
        self.createDirectory(self.__model_dir)
        
        # known name and encoding list
        self.__known_names = []
        self.__knwon_face_encodings = []
        
        self.__known_names_filename = known_names_filename
        self.__known_encoding_filename = known_encoding_filename
        
    def __getFiles(self) -> iter:
        for files in os.listdir(self.images_dir):
            print(f"{files} Training....")
            yield files
            
    def __getFileNames(self, filename) -> None:
        
        # add the filename without extention to knwon names list
        self.__known_names.append(filename.split(".")[0])
        
    def __getFaceEncodings(self, filename) -> None:
        
        # Load image 
        face_recognition_image_loaded = FaceRecognition()._FaceRecognition__load_image_from_file(f"{self.images_dir}/{filename}")
        
        # Get face Encodings from Face Recognition
        face_recognition_image_encodings = FaceRecognition()._FaceRecognition__get_face_encodings(
            fr_img = face_recognition_image_loaded
            )
        
        # Add the face encodings to known face encodings list
        self.__knwon_face_encodings.append(face_recognition_image_encodings[0])
    
    def __saveModel(self):
            
            # save knwon names
            self.savePickleModel(
                model_dir=self.__model_dir,
                filename=self.__known_names_filename, 
                data=self.__known_names)
            
            # Saved known encodings
            self.savePickleModel(
                model_dir=self.__model_dir,
                filename=self.__known_encoding_filename, 
                data=self.__knwon_face_encodings)

    def train(self) -> None:
        
        for filename in self.__getFiles():
            self.__getFileNames(filename=filename)
            self.__getFaceEncodings(filename=filename)
            
        print("\n")
        
        self.__saveModel()
                    
            
if __name__ == "__main__":
    train_faces = TrainFaces()
    train_faces.train()