
# Threading 
import threading

# OpenCV
import cv2
import cvlib as cv
import time

# PIL package
from PIL import ImageDraw

# Face Recognition package
# import face_recognition
import numpy as np

from utils.utils import Utils
from utils._faceRecognition import FaceRecognition
from utils._camera import Camera
#from utils._genderDetection import GenderDetection

utils = Utils()
print("Model loaded successfully...\n")
    
known_name_model = utils.loadPickleModel("model/known-names.pkl")
known_face_encoding_model = utils.loadPickleModel("model/known-face-encodings.pkl")

class CustomCamera(Camera):

    def __init__(self, cam_index: int = 0, cam_prop: cv2 = cv2.CAP_DSHOW):
        super().__init__(cam_index, cam_prop)
        self.pTime = 0
        
        self.counter = 0
        self.frame_skip = 5 
        
        #self.__genderDetection = GenderDetection()
        
    def __getFps(self) -> str:
        
        self.cTime = time.time()
        fps = int(1 / (self.cTime - self.pTime))
        self.pTime = self.cTime
        
        return str(fps)+" fps"
    
    
    def start(self) -> None:
        self._setCamSize()
        
        
        name = "Unknonw Person"
        pervName = None
                
        
        while self.run :
            
            _, __frame = self.cap.read()
            __frame = cv2.resize(__frame, (0, 0), fx=0.25, fy=0.25)
            __frameCopy = __frame.copy()
            rgb_frame = cv2.cvtColor(__frame, cv2.COLOR_BGR2RGB)
            #frame_array = np.array(__frame)

            # Get Face Locations
            face_locations = FaceRecognition()._FaceRecognition__get_face_locations(rgb_frame)
            
            # Get face encodings
            face_encodings = FaceRecognition()._FaceRecognition__get_face_encodings(fr_img=rgb_frame, findFace=True, faceLocations=face_locations)
      
            
            for (t, r, b ,l), face_encoding in zip(face_locations, face_encodings):
                cv2.rectangle(__frame, (l, t), (r, b), (0, 0, 0), 1)
                
                matches = FaceRecognition().compareFaces(known_face_encoding_model, face_encoding)
                print(matches)
                name = "Unknonw Person"
                if True in matches:
                    name = known_name_model[matches.index(True)]
                #s = self.__genderDetection.predict(__frame, [l, t, r, b])
                print(name)
                
                if name != pervName:
                    #utils.speakText(f"{name}")
                    pervName = name
                
                cv2.rectangle(__frame, (l, b - len(name) - 10), (r, b), color=(0, 0, 0), thickness=-1 )
                cv2.putText(__frame, name, (l+6, b-len(name) + 5), fontScale=0.5, color=(255, 255, 255),fontFace=cv2.FONT_HERSHEY_PLAIN ,thickness=1) 
        
                #cv2.putText(__frame, s, (l, t), fontScale=0.7, color=(255, 255, 255),fontFace=cv2.FONT_HERSHEY_PLAIN ,thickness=1) 
        

            cv2.putText(__frame, self.__getFps(), (10, 10), fontScale=1,fontFace=cv2.FONT_HERSHEY_PLAIN, color=(200, 200, 200))
            cv2.imshow("Frame", __frame)
            #try:cv2.imshow("crop", crop)
            #except:pass
            
            del face_encodings
            del face_locations
            del rgb_frame
            
            if self._stopCam():
                break
        


def testImage():
    from utils.utils import Utils
    from utils._faceRecognition import FaceRecognition
    
    utils = Utils()
    face_recognition = FaceRecognition()
    
    print("Model loaded successfuly...\n")
    
    known_name_model = utils.loadPickleModel("model/known-names.pkl")
    known_face_encoding_model = utils.loadPickleModel("model/known-face-encodings.pkl")
    
    
    print("Image Loaded Successfuly...\n")
    # load test image
    test_image = FaceRecognition()._FaceRecognition__load_image_from_file(file_path = "captain-america.jpeg")
    
    print("Get Face Locations successfuly...\n")
    # Get Face Locations
    face_locations = FaceRecognition()._FaceRecognition__get_face_locations(test_image)
    
    print("Get Face Encodings successfuly...\n")
    # Get Face Encodings
    face_encodings = FaceRecognition()._FaceRecognition__get_face_encodings(fr_img=test_image, findFace=True, faceLocations=face_locations)
    
    # Convert to PIL format
    pil_image = FaceRecognition().convertToPilFormat(test_image)
    
    # Craete a ImageDraw instance
    imageDraw = ImageDraw.Draw(pil_image)
    
    
    # Loops through faces in test image
    for (t, r, b ,l), face_encoding in zip(face_locations, face_encodings):
        matches = FaceRecognition().compareFaces(known_face_encoding_model, face_encoding)
        print(matches)
        
        name = "Unknonw Person"
        
        if True in matches:
            name = known_name_model[matches.index(True)]
            print(name)
            
        # Draw Box 
        imageDraw.rectangle(((l, t), (r, b)), outline=(0,0,0))
        
        # Draw label
        _, textHeight = imageDraw.textsize(name)
        imageDraw.rectangle(((l, b - textHeight - 10), (r, b)), fill=(0,0,0), outline=(0,0,0))
        
        # Draw Text
        imageDraw.text((l+6, b-textHeight - 5), name, fill=(255, 255, 255)) 
        
    
    del imageDraw
    
    # Display Image
    pil_image.show()



if __name__ == "__main__":
    custom_camera =CustomCamera(cam_index=0)
    custom_camera.start()
    
#    pil_image.save("abc.jpg")




